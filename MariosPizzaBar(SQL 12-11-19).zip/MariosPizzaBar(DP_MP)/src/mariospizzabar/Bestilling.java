//@Author Mathias
package mariospizzabar;

import java.sql.SQLException;
import java.util.ArrayList;
import mariospizzabar.DataMapper.PizzaMapper;

public class Bestilling implements Comparable<Object> {

    private int nummer;
    private String kundeNavn;
    private ArrayList<Pizza> pizzaer;
    private int tid1;
    private int tid2;
    private String tidspunkt;

    public Bestilling(ArrayList<Pizza> pizzaer, String inhold, String tidspunkt, int nummer) {
        this.kundeNavn = inhold;
        this.nummer = nummer;
        this.pizzaer = pizzaer;
        this.tidspunkt = tidspunkt;
    }

    public int getNummer() {
        return nummer;
    }

    public int getTid() {
        String firstNr = "";
        String secondNr = "";
        int firstInt = 0;
        int secondInt = 0;
        int retInt = 0;

        String bestilString = getTidspunkt();
        if (bestilString.contains(":")) {
            int idx1 = bestilString.indexOf(":");
            firstNr = bestilString.substring(idx1 - 2, idx1);
            secondNr = bestilString.substring(idx1 + 1, idx1 + 2);
            firstInt = Integer.parseInt(firstNr);
            secondInt = Integer.parseInt(secondNr);

        }

        this.tid1 = firstInt;
        this.tid2 = secondInt;

        retInt = firstInt;
        return retInt;
    }

    public int getTid2() {
        return this.tid2;
    }

    public String getTidspunkt() {
        return tidspunkt;
    }

    public String getPizzaer() {
        String result = "";
        for (Pizza pizza : pizzaer) {
            result += pizza.toString();
        }
        return result;
    }

    public ArrayList<Pizza> getPizzaArr() {
        return this.pizzaer;
    }

    public void setNummer() throws ClassNotFoundException, SQLException {
        int maxID = PizzaMapper.getMaxOrdreID();

        this.nummer = maxID + 1;

    }

    public String getKundeNavn() {
        return kundeNavn;
    }

    public void setKundeNavn(String kundeNavn) {
        this.kundeNavn = kundeNavn;
    }

    @Override
    public String toString() {
        String result;
        result = getPizzaer() + " Til " + kundeNavn + " kl. " + getTidspunkt();
        return result;
    }

    //Sorterer bestillingerne efter tid.
    @Override
    public int compareTo(Object bestilling2) {
        Bestilling otherBestilling = (Bestilling) bestilling2;
        int thisHour = this.getTid();
        int thisMinute = this.getTid2();
        int otherHour = otherBestilling.getTid();
        int otherMinute = otherBestilling.getTid2();
        int result = 0;
        if (thisHour > otherHour && thisMinute > otherMinute) {
            result = 1;
        } else if (thisHour > otherHour && thisMinute == otherMinute) {
            result = 1;
        } else if (thisHour == otherHour && thisMinute > otherMinute) {
            result = 1;
        } else if (thisHour > otherHour && thisMinute < otherMinute) {
            result = 1;
        } else if (thisHour < otherHour && thisMinute < otherMinute) {
            result = -1;
        } else if (thisHour < otherHour && thisMinute > otherMinute) {
            result = -1;
        } else if (thisHour < otherHour && thisMinute == otherMinute) {
            result = -1;
        } else if (thisHour == otherHour && thisMinute < otherMinute) {
            result = -1;
        } else if (thisHour == otherHour && thisMinute == otherMinute) {
            result = 0;
        }

        return result;
    }

}
