package mariospizzabar.DataMapper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import mariospizzabar.Bestilling;
import mariospizzabar.Pizza;
import mariospizzabar.Util.DBConnector;

public class PizzaMapper {

    public static ArrayList<Pizza> pizzaList() throws SQLException, ClassNotFoundException {
        ArrayList<Pizza> returnList = new ArrayList();
        Connection myConnector = null;
        Statement statement = null;
        ResultSet resultSet = null;

        myConnector = DBConnector.getConnector();
        String query = "SELECT * FROM pizza";
        statement = myConnector.createStatement();
        resultSet = statement.executeQuery(query);

        while (resultSet.next()) {
            String pizzaNavn = resultSet.getString("navn");
            int pizzaNummer = resultSet.getInt("nummer");
            String toppings = resultSet.getString("toppings");
            double pris = resultSet.getDouble("pris");
            Pizza tmpPizza = new Pizza(pizzaNummer, pizzaNavn, toppings, pris);
            returnList.add(tmpPizza);
        }

        //Lukker efter sig
        resultSet.close();
        statement.close();
        myConnector.close();

        return returnList;
    }

    public static void bestillingInsert(Bestilling bestilling) throws SQLException, ClassNotFoundException {
        ArrayList<Pizza> pizzaer = bestilling.getPizzaArr();
        Connection myConnector = null;
        PreparedStatement pstmt = null;

        bestilling.setNummer();
        int bestilNR = bestilling.getNummer();
        String tidspunkt = bestilling.getTidspunkt();
        String kundeNavn = bestilling.getKundeNavn();
        myConnector = DBConnector.getConnector();

        for (Pizza p : pizzaer) {

            String query = "INSERT INTO bestillingpizzalink (ordreid, pizzanr) values (?, ?);";

            pstmt = myConnector.prepareStatement(query);
            pstmt.setInt(1, bestilNR);
            pstmt.setInt(2, p.getNummer());
            pstmt.execute();

        }

        String query = "insert into bestilling (ordreID, tid, kundeNavn) values (?, ?, ?);";
        pstmt = myConnector.prepareStatement(query);
        pstmt.setInt(1, bestilNR);
        pstmt.setString(2, tidspunkt);
        pstmt.setString(3, kundeNavn);
        pstmt.execute();

        pstmt.close();
        myConnector.close();
    }

    //Finder maxværdien af alle ordreID'er i databasen bestilling.
    public static int getMaxOrdreID() throws ClassNotFoundException, SQLException {
        Connection myConnector = null;
        Statement statement = null;
        ResultSet resultSet = null;
        int maxID = 0;

        myConnector = DBConnector.getConnector();
        String query = "SELECT max(ordreID) from bestillingpizzalink";
        statement = myConnector.createStatement();
        resultSet = statement.executeQuery(query);
        resultSet.next();
        maxID = resultSet.getInt(1);

        resultSet.close();
        myConnector.close();
        statement.close();

        return maxID;
    }

    //Laver statestik ud fra databasen.
    public static String lavStatestikFromDB() throws ClassNotFoundException, SQLException {
        Connection myConnector = null;
        Statement statement = null;
        ResultSet resultSet = null;

        int omsætning = 0;
        int populær = 0;
        String returnString;

        myConnector = DBConnector.getConnector();
        String query1 = "SELECT SUM(pris) as Omsætning, COUNT(bestillingpizzalink.pizzanr) AS AntalPizza FROM pizza JOIN bestillingpizzalink ON pizza.nummer = bestillingpizzalink.pizzanr ORDER BY pizzanr;";
        String query2 = "SELECT pizzanr, COUNT(pizzanr) AS Antal FROM bestillingpizzalink GROUP BY pizzanr ORDER BY antal desc LIMIT 1;";

        statement = myConnector.createStatement();
        resultSet = statement.executeQuery(query1);
        resultSet.next();
        omsætning = resultSet.getInt("Omsætning");

        statement = myConnector.createStatement();
        resultSet = statement.executeQuery(query2);
        resultSet.next();
        populær = resultSet.getInt("pizzanr");

        statement.close();
        resultSet.close();
        myConnector.close();

        returnString = "Samlet omsætning: " + omsætning + "\nMest populære pizza er pizza nummer " + populær;

        return returnString;
    }

}
