//@Daniel
package mariospizzabar;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import mariospizzabar.PizzaFile.StringParserHelper;

public class PizzaStatistik {

    //Pizzaerne fra gamleOrdrer bliver ført fra arraylisten "arr" og til arrayet "array".
    public static int populær(ArrayList<Integer> arr) {
        int size = arr.size();
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = arr.get(i);
        }
        //Det hyppigste tal bliver fundet og gemt.
        int element = 0;
        int count = 0;
        for (int i = 0; i < array.length; i++) {
            int tempElement = array[i];
            int tempCount = 0;
            for (int j = 0; j < array.length; j++) {
                if (array[j] == tempElement) {
                    tempCount++;
                }
                if (tempCount > count) {
                    element = tempElement;
                    count = tempCount;
                }

            }

        }
        
        return element;
    }

}
