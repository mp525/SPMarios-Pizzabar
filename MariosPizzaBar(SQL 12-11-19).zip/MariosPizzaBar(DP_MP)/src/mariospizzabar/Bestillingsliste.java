//@Author Mathias
package mariospizzabar;

import java.util.ArrayList;
import java.util.Collections;

public class Bestillingsliste { //Her bliver bestillinger skrevet ind og håndteret af Alfonso alt efter behov.

    private ArrayList<Bestilling> bestillinger = new ArrayList();

    public Bestillingsliste() {

    }

    public void tilføjBestilling(Bestilling bestilling) {
        bestillinger.add(bestilling);
    }

    public void fjernBestilling(int nummer) {
        Bestilling bestillingFjern = null;
        for (Bestilling bestilling : bestillinger) {
            if (bestilling.getNummer() == nummer) {
                bestillingFjern = bestilling;
            }

        }

        bestillinger.remove(bestillingFjern);

    }

    public Bestilling getBestilling(int nummer) {
        Bestilling bestillingUd = null;
        for (Bestilling bestilling : bestillinger) {
            if (bestilling.getNummer() == nummer) {
                bestillingUd = bestilling;
            }
        }
        return bestillingUd;
    }

    public void sorterBestillinger(Bestilling bestilling) {
        Collections.sort(bestillinger);
    }

    @Override
    public String toString() {
        int count = 1;
        String bestillinger = "Bestillinger: \n";
        for (Bestilling bestilling : this.bestillinger) {
            bestillinger += bestilling.getNummer() + ":" + bestilling.toString() + "\n";
            count++;
        }
        return bestillinger;
    }

}
