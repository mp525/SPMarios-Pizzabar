//@Author Mathias og Daniel
package mariospizzabar;

import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class BestillingTest {

    Pizza pizza1;
    Pizza pizza2;
    Bestilling bestilling1;
    ArrayList<Pizza> list1 = new ArrayList<Pizza>();

    public BestillingTest() {
    }

    @Before
    public void setUp() {
        pizza1 = new Pizza(1, "Vesuvio", "tomatsauce, ost, skinke, oregano", 57.0);
        pizza2 = new Pizza(2, "Amerikaner", "tomatsauce, ost, oksefars, oregano", 53.0);
        list1.add(pizza1);
        list1.add(pizza2);
        bestilling1 = new Bestilling(list1, "tomatsauce, ost, skinke, pepperoni, cocktailpølser, oregano", 1);

    }

    //Vi tester om getNummer metoden virker fra Bestillingklassen.
    @Test
    public void testGetNummer() {
        int expResult = 1;
        int result = bestilling1.getNummer();
        assertEquals(expResult, result);

    }

}
