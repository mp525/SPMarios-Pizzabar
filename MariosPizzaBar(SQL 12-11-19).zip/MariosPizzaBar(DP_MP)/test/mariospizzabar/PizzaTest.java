//@Author Mathias og Daniel
package mariospizzabar;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class PizzaTest {

    public PizzaTest() {
    }

    @Before
    public void setUp() {
    }

    //Vi tester om getNavn metoden fra Pizzaklassen virker.
    @Test
    public void testGetNavn() {
        System.out.println("getNavn");
        Pizza pizzaTest = new Pizza(1, "Vesuvio", "tomatsauce, ost, skinke, oregano", 57.0);
        String expResult = "Vesuvio";
        String result = pizzaTest.getNavn();
        assertEquals(expResult, result);

    }

}
