//@Author Mathias og Daniel
package mariospizzabar;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import mariospizzabar.PizzaFile.StringParserHelper;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class PizzaStatistikTest {

    public PizzaStatistikTest() {
    }

    @Before
    public void setUp() {
    }

    //Vi tester om populær metoden fra PizzaStatistikklassen virker.
    @Test
    public void testPopulær() throws FileNotFoundException {
        ArrayList<Integer> arr = StringParserHelper.addPizzaNumber();

        int expResult = 7;
        int result = PizzaStatistik.populær(arr);
        assertEquals(expResult, result);

    }

}
