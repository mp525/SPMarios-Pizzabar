//@Author Mathias
package mariospizzabar;

import java.util.ArrayList;

public class Bestilling implements Comparable<Object> {

    private int nummer;
    private String indhold;
    private ArrayList<Pizza> pizzaer;
    private int tid1;
    private int tid2;

    public Bestilling(ArrayList<Pizza> pizzaer, String inhold, int nummer) {
        this.indhold = inhold;
        this.nummer = nummer;
        this.pizzaer = pizzaer;
    }

    public int getNummer() {
        return nummer;
    }

    public void nummerMinus() {
        this.nummer = nummer--;
    }

    public int getTid() {
        String firstNr = "";
        String secondNr = "";
        int firstInt = 0;
        int secondInt = 0;
        int retInt = 0;

        String bestilString = getIndhold();
        if (bestilString.contains(":")) {
            int idx1 = bestilString.indexOf(":");
            firstNr = bestilString.substring(idx1 - 2, idx1);
            secondNr = bestilString.substring(idx1 + 1, idx1 + 2);
            firstInt = Integer.parseInt(firstNr);
            secondInt = Integer.parseInt(secondNr);

        }

        this.tid1 = firstInt;
        this.tid2 = secondInt;
        retInt = firstInt;
        return retInt;
    }

    public int getTid2() {
        return this.tid2;
    }

    public String getPizzaer() {
        String result = "";
        for (Pizza pizza : pizzaer) {
            result += pizza.toString();
        }
        return result;
    }

    public void setNummer(int nummer) {
        this.nummer = nummer;
    }

    public String getIndhold() {
        return indhold;
    }

    public void setIndhold(String indhold) {
        this.indhold = indhold;
    }

    @Override
    public String toString() {
        String result;
        result = getPizzaer() + " Til " + indhold;
        return result;
    }

    //Sorterer bestillingerne efter tid.
    @Override
    public int compareTo(Object bestilling2) {
        Bestilling otherBestilling = (Bestilling) bestilling2;
        int thisHour = this.getTid();
        int thisMinute = this.getTid2();
        int otherHour = otherBestilling.getTid();
        int otherMinute = otherBestilling.getTid2();
        int result = 0;
        if (thisHour > otherHour && thisMinute > otherMinute) {
            result = 1;
        } else if (thisHour > otherHour && thisMinute == otherMinute) {
            result = 1;
        } else if (thisHour == otherHour && thisMinute > otherMinute) {
            result = 1;
        } else if (thisHour > otherHour && thisMinute < otherMinute) {
            result = 1;
        } else if (thisHour < otherHour && thisMinute < otherMinute) {
            result = -1;
        } else if (thisHour < otherHour && thisMinute > otherMinute) {
            result = -1;
        } else if (thisHour < otherHour && thisMinute == otherMinute) {
            result = -1;
        } else if (thisHour == otherHour && thisMinute < otherMinute) {
            result = -1;
        } else if (thisHour == otherHour && thisMinute == otherMinute) {
            result = 0;
        }

        return result;
    }

}
