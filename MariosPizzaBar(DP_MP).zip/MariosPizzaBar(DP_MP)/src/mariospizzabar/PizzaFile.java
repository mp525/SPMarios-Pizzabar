//@Author Mathias og Daniel
package mariospizzabar;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class PizzaFile {

    static String filename = "gamleOrdrer.txt";

    static class StringParserHelper {

        //Finder tallet før ".0" og returner dem som string.
        public static String getPizzaPrice(String pizza) {
            if (pizza.contains(".0")) {
                int idx = pizza.indexOf(".0");
                pizza = pizza.substring(idx - 2, idx);

            }
            return pizza;
        }

        //Finder pizzanummeret og tilføjer det til arraylisten "arr".
        public static ArrayList<Integer> addPizzaNumber() throws FileNotFoundException {
            String line = "";
            int tal;
            int i = 0;
            File filename = new File("gamleOrdrer.txt");
            Scanner fileScan2 = new Scanner(filename);

            ArrayList<Integer> arr = new ArrayList();

            while (fileScan2.hasNextLine()) {
                line = fileScan2.nextLine();
                String[] lineArr = line.split(",");
                String pizNr = lineArr[0];
                String[] fieldArr = pizNr.split(" ");
                tal = Integer.parseInt(fieldArr[fieldArr.length - 1]);
                arr.add(tal);

            }

            return arr;
        }

    }

    static class FileImporter {

        public static void readFile() throws FileNotFoundException, IOException { //Finder sum/omsætning

            String line = "";
            int sum = 0;
            File filename = new File("gamleOrdrer.txt");
            Scanner fileScan = new Scanner(filename);
            while (fileScan.hasNextLine()) {
                line = fileScan.nextLine();
                String tal = StringParserHelper.getPizzaPrice(line);
                int i = Integer.parseInt(tal);
                sum = sum + i;

            }
            System.out.println("Samlet omsætning: " + sum + " kr");
        }
    }
}
